package nz.ac.auckland.se754.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.util.Map;

public class CheckoutPage {
    private Map<String, String> data;
    private WebDriver driver;
    private int timeout = 15;

    @FindBy(id = "address")
    @CacheLookup
    private WebElement address;

    @FindBy(id = "card")
    @CacheLookup
    private WebElement cardNumber;

    @FindBy(id = "cardType")
    @CacheLookup
    private WebElement cardType;

    @FindBy(css = "a[href='#/cart']")
    @CacheLookup
    private WebElement cart1;

    @FindBy(css = "a[href='#/contact']")
    @CacheLookup
    private WebElement contact;

    @FindBy(id = "email")
    @CacheLookup
    private WebElement email;


    @FindBy(css = "a[href='#/home']")
    @CacheLookup
    private WebElement home;

    @FindBy(css = "a.brand")
    @CacheLookup
    private WebElement jupiterToys;

    @FindBy(css = "#nav-login ng-login a")
    @CacheLookup
    private WebElement login;

    @FindBy(css = "#nav-logout a")
    @CacheLookup
    private WebElement logout;

    private final String pageLoadedText = "send spam email or give your email address to others";

    private final String pageUrl = "/#/checkout";

    @FindBy(how=How.ID, using= "forename")
    @CacheLookup
    private WebElement forename;

    @FindBy(css = "#nav-shop a")
    @CacheLookup
    private WebElement shop;

    @FindBy(css = "a.btn.btn-success")
    @CacheLookup
    private WebElement startShopping;

    @FindBy(id = "checkout-submit-btn")
    @CacheLookup
    private WebElement submit;

    @FindBy(id = "surname")
    @CacheLookup
    private WebElement surname;

    @FindBy(id = "telephone")
    @CacheLookup
    private WebElement telephone;

    @FindBy(xpath = "/html/body/div[2]/div/div[2]/div/div")
    @CacheLookup
    private WebElement checkoutErr;

    @FindBy(xpath = "/html/body/div[2]/div/form/table/tfoot/tr[2]/td/ng-confirm")
    @CacheLookup
    private WebElement emptyCartBtn;

    @FindBy(xpath = "/html/body/div[3]/div[3]/a[1]")
    @CacheLookup
    private WebElement confirmEmptyCartBtn;

    @FindBy(xpath = "/html/body/div[2]/div/form/table/tbody/tr/td[5]/ng-confirm/a")
    @CacheLookup
    private WebElement removeItemBtn;


    @FindBy(xpath = "/html/body/div[2]/div/div[2]/form/fieldset[1]/div[1]/div/input")
    @CacheLookup
    private WebElement fName;

    @FindBy(xpath = "/html/body/div[2]/div/div")
    @CacheLookup
    private WebElement purchaseSuccessMsg;

    public CheckoutPage() {
    }

    public CheckoutPage(WebDriver driver) {
        this();
        PageFactory.initElements(driver, this);
        this.driver = driver;
    }

    public CheckoutPage(WebDriver driver, Map<String, String> data) {
        this();
        PageFactory.initElements(driver, this);
        this.data = data;
    }

    public CheckoutPage(WebDriver driver, Map<String, String> data, int timeout) {
        this(driver, data);
        this.timeout = timeout;
    }

    public String getPurchaseSuccessMsg(){
        return purchaseSuccessMsg.getText().toString();
    }

    public WebElement getfName() {
        return fName;
    }

    /**
     * Click on Cart 1 Link.
     *
     * @return the CheckOutPage class instance.
     */
    public CheckoutPage clickCart1Link() {
        cart1.click();
        return this;
    }

    public WebElement getCheckoutErr() {
        return checkoutErr;
    }

    public CheckoutPage clickEmptyCartButton() {
        emptyCartBtn.click();
        return this;
    }

    public CheckoutPage clickConfirmEmptyCartButton() {
        confirmEmptyCartBtn.click();
        return this;
    }
    public CheckoutPage clickRemoveItemButton() {
        removeItemBtn.click();
        return this;
    }


    /**
     * Click on Contact Link.
     *
     * @return the CheckOutPage class instance.
     */
    public CheckoutPage clickContactLink() {
        contact.click();
        return this;
    }

    /**
     * Click on Home Link.
     *
     * @return the CheckOutPage class instance.
     */
    public CheckoutPage clickHomeLink() {
        home.click();
        return this;
    }

    /**
     * Click on Jupiter Toys Link.
     *
     * @return the CheckOutPage class instance.
     */
    public CheckoutPage clickJupiterToysLink() {
        jupiterToys.click();
        return this;
    }

    /**
     * Click on Login Link.
     *
     * @return the CheckOutPage class instance.
     */
    public CheckoutPage clickLoginLink() {
        login.click();
        return this;
    }

    /**
     * Click on Logout Link.
     *
     * @return the CheckOutPage class instance.
     */
    public CheckoutPage clickLogoutLink() {
        logout.click();
        return this;
    }

    /**
     * Click on Shop Link.
     *
     * @return the CheckOutPage class instance.
     */
    public CheckoutPage clickShopLink() {
        shop.click();
        return this;
    }

    /**
     * Click on Start Shopping Link.
     *
     * @return the CheckOutPage class instance.
     */
    public CheckoutPage clickStartShoppingLink() {
        startShopping.click();
        return this;
    }

    /**
     * Click on Submit Button.
     *
     * @return the CheckOutPage class instance.
     */
    public CheckoutPage clickSubmitButton() {
        submit.click();
        return this;
    }

    /**
     * Fill every fields in the page.
     *
     * @return the CheckOutPage class instance.
     */
    public CheckoutPage fill() {
        setForenameTextField();
        setSurnameTextField();
        setEmailEmailField();
        setTelephoneTelField();
        setAddressTextareaField();
        setCardTypeDropDownListField();
        setCardNumberTextField();
        return this;
    }

    /**
     * Fill every fields in the page and submit it to target page.
     *
     * @return the CheckOutPage class instance.
     */
    public CheckoutPage fillAndSubmit() {
        fill();
        return submit();
    }

    /**
     * Set default value to Address Textarea field.
     *
     * @return the CheckOutPage class instance.
     */
    public CheckoutPage setAddressTextareaField() {
        return setAddressTextareaField(data.get("ADDRESS"));
    }

    /**
     * Set value to Address Textarea field.
     *
     * @return the CheckOutPage class instance.
     */
    public CheckoutPage setAddressTextareaField(String addressValue) {
        address.sendKeys(addressValue);
        return this;
    }

    /**
     * Set default value to Card Number Text field.
     *
     * @return the CheckOutPage class instance.
     */
    public CheckoutPage setCardNumberTextField() {
        return setCardNumberTextField(data.get("CARD_NUMBER"));
    }

    /**
     * Set value to Card Number Text field.
     *
     * @return the CheckOutPage class instance.
     */
    public CheckoutPage setCardNumberTextField(String cardNumberValue) {
        cardNumber.sendKeys(cardNumberValue);
        return this;
    }

    /**
     * Set default value to Card Type Drop Down List field.
     *
     * @return the CheckOutPage class instance.
     */
    public CheckoutPage setCardTypeDropDownListField() {
        return setCardTypeDropDownListField(data.get("CARD_TYPE"));
    }

    /**
     * Set value to Card Type Drop Down List field.
     *
     * @return the CheckOutPage class instance.
     */
    public CheckoutPage setCardTypeDropDownListField(String cardTypeValue) {
        new Select(cardType).selectByVisibleText(cardTypeValue);
        return this;
    }

    /**
     * Set default value to Email Email field.
     *
     * @return the CheckOutPage class instance.
     */
    public CheckoutPage setEmailEmailField() {
        return setEmailEmailField(data.get("EMAIL"));
    }

    /**
     * Set value to Email Email field.
     *
     * @return the CheckOutPage class instance.
     */
    public CheckoutPage setEmailEmailField(String emailValue) {
        email.sendKeys(emailValue);
        return this;
    }

    /**
     * Set default value to Forename Text field.
     *
     * @return the CheckOutPage class instance.
     */
    public CheckoutPage setForenameTextField() {
        return setForenameTextField(data.get("FORENAME"));
    }

    /**
     * Set value to Forename Text field.
     *
     * @return the CheckOutPage class instance.
     */
    public CheckoutPage setForenameTextField(String forenameValue) {
        forename.sendKeys(forenameValue);
        return this;
    }

    /**
     * Set default value to Surname Text field.
     *
     * @return the CheckOutPage class instance.
     */
    public CheckoutPage setSurnameTextField() {
        return setSurnameTextField(data.get("SURNAME"));
    }

    /**
     * Set value to Surname Text field.
     *
     * @return the CheckOutPage class instance.
     */
    public CheckoutPage setSurnameTextField(String surnameValue) {
        surname.sendKeys(surnameValue);
        return this;
    }

    /**
     * Set default value to Telephone Tel field.
     *
     * @return the CheckOutPage class instance.
     */
    public CheckoutPage setTelephoneTelField() {
        return setTelephoneTelField(data.get("TELEPHONE"));
    }

    /**
     * Set value to Telephone Tel field.
     *
     * @return the CheckOutPage class instance.
     */
    public CheckoutPage setTelephoneTelField(String telephoneValue) {
        telephone.sendKeys(telephoneValue);
        return this;
    }

    /**
     * Submit the form to target page.
     *
     * @return the CheckOutPage class instance.
     */
    public CheckoutPage submit() {
        clickSubmitButton();
        return this;
    }

    /**
     * Unset default value from Card Type Drop Down List field.
     *
     * @return the CheckOutPage class instance.
     */
    public CheckoutPage unsetCardTypeDropDownListField() {
        return unsetCardTypeDropDownListField(data.get("CARD_TYPE"));
    }

    /**
     * Unset value from Card Type Drop Down List field.
     *
     * @return the CheckOutPage class instance.
     */
    public CheckoutPage unsetCardTypeDropDownListField(String cardTypeValue) {
        new Select(cardType).deselectByVisibleText(cardTypeValue);
        return this;
    }

    /**
     * Verify that the page loaded completely.
     *
     * @return the CheckOutPage class instance.
     */
    public CheckoutPage verifyPageLoaded() {
        (new WebDriverWait(driver, timeout)).until(new ExpectedCondition<Boolean>() {
            public Boolean apply(WebDriver d) {
                return d.getPageSource().contains(pageLoadedText);
            }
        });
        return this;
    }

    /**
     * Verify that current page URL matches the expected URL.
     *
     * @return the CheckOutPage class instance.
     */
    public CheckoutPage verifyPageUrl() {
        (new WebDriverWait(driver, timeout)).until(new ExpectedCondition<Boolean>() {
            public Boolean apply(WebDriver d) {
                return d.getCurrentUrl().contains(pageUrl);
            }
        });
        return this;
    }
}

