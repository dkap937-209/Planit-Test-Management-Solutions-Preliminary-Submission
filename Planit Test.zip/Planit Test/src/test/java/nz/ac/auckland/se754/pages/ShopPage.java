package nz.ac.auckland.se754.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.util.Map;

public class ShopPage {
    private Map<String, String> data;
    private WebDriver driver;
    private int timeout = 15;

    @FindBy(css = "#product-1 div p a.btn.btn-success")
    @CacheLookup
    private WebElement buy1;

    @FindBy(css = "#product-2 div p a.btn.btn-success")
    @CacheLookup
    private WebElement buy2;

    @FindBy(css = "#product-3 div p a.btn.btn-success")
    @CacheLookup
    private WebElement buy3;

    @FindBy(css = "#product-4 div p a.btn.btn-success")
    @CacheLookup
    private WebElement buy4;

    @FindBy(css = "#product-5 div p a.btn.btn-success")
    @CacheLookup
    private WebElement buy5;

    @FindBy(css = "#product-6 div p a.btn.btn-success")
    @CacheLookup
    private WebElement buy6;

    @FindBy(css = "#product-7 div p a.btn.btn-success")
    @CacheLookup
    private WebElement buy7;

    @FindBy(css = "#product-8 div p a.btn.btn-success")
    @CacheLookup
    private WebElement buy8;

    @FindBy(css = "a[href='#/cart']")
    @CacheLookup
    private WebElement cart0;

    @FindBy(css = "a[href='#/contact']")
    @CacheLookup
    private WebElement contact;

    @FindBy(css = "a[href='#/home']")
    @CacheLookup
    private WebElement home;

    @FindBy(css = "a.brand")
    @CacheLookup
    private WebElement jupiterToys;

    @FindBy(css = "#nav-login ng-login a")
    @CacheLookup
    private WebElement login;

    @FindBy(css = "#nav-logout a")
    @CacheLookup
    private WebElement logout;

    private final String pageLoadedText = "";

    private final String pageUrl = "/#/shop";

    @FindBy(css = "a[href='#/shop']")
    @CacheLookup
    private WebElement shop;


    @FindBy(xpath = "/html/body/div[2]/div/p/span[2]")
    @CacheLookup
    private WebElement itemQuantity;

    public ShopPage() {
    }

    public ShopPage(WebDriver driver) {
        this();
        PageFactory.initElements(driver, this);
        this.driver = driver;
    }

    public ShopPage(WebDriver driver, Map<String, String> data) {
        this(driver);
        this.data = data;
    }

    public ShopPage(WebDriver driver, Map<String, String> data, int timeout) {
        this(driver, data);
        this.timeout = timeout;
    }

    public WebElement getItemQuantity() {
        return itemQuantity;
    }

    /**
     * Click on Buy Link.
     *
     * @return the ShopPage class instance.
     */
    public ShopPage clickBuy1Link() {
        buy1.click();
        return this;
    }

    /**
     * Click on Buy Link.
     *
     * @return the ShopPage class instance.
     */
    public ShopPage clickBuy2Link() {
        buy2.click();
        return this;
    }

    /**
     * Click on Buy Link.
     *
     * @return the ShopPage class instance.
     */
    public ShopPage clickBuy3Link() {
        buy3.click();
        return this;
    }

    /**
     * Click on Buy Link.
     *
     * @return the ShopPage class instance.
     */
    public ShopPage clickBuy4Link() {
        buy4.click();
        return this;
    }

    /**
     * Click on Buy Link.
     *
     * @return the ShopPage class instance.
     */
    public ShopPage clickBuy5Link() {
        buy5.click();
        return this;
    }

    /**
     * Click on Buy Link.
     *
     * @return the ShopPage class instance.
     */
    public ShopPage clickBuy6Link() {
        buy6.click();
        return this;
    }

    /**
     * Click on Buy Link.
     *
     * @return the ShopPage class instance.
     */
    public ShopPage clickBuy7Link() {
        buy7.click();
        return this;
    }

    /**
     * Click on Buy Link.
     *
     * @return the ShopPage class instance.
     */
    public ShopPage clickBuy8Link() {
        buy8.click();
        return this;
    }

    /**
     * Click on Cart 0 Link.
     *
     * @return the ShopPage class instance.
     */
    public ShopPage clickCart0Link() {
        cart0.click();
        return this;
    }

    /**
     * Click on Contact Link.
     *
     * @return the ShopPage class instance.
     */
    public ShopPage clickContactLink() {
        contact.click();
        return this;
    }

    /**
     * Click on Home Link.
     *
     * @return the ShopPage class instance.
     */
    public ShopPage clickHomeLink() {
        home.click();
        return this;
    }

    /**
     * Click on Jupiter Toys Link.
     *
     * @return the ShopPage class instance.
     */
    public ShopPage clickJupiterToysLink() {
        jupiterToys.click();
        return this;
    }

    /**
     * Click on Login Link.
     *
     * @return the ShopPage class instance.
     */
    public ShopPage clickLoginLink() {
        login.click();
        return this;
    }

    /**
     * Click on Logout Link.
     *
     * @return the ShopPage class instance.
     */
    public ShopPage clickLogoutLink() {
        logout.click();
        return this;
    }

    /**
     * Click on Shop Link.
     *
     * @return the ShopPage class instance.
     */
    public ShopPage clickShopLink() {
        shop.click();
        return this;
    }

    /**
     * Verify that the page loaded completely.
     *
     * @return the ShopPage class instance.
     */
    public ShopPage verifyPageLoaded() {
        (new WebDriverWait(driver, timeout)).until(new ExpectedCondition<Boolean>() {
            public Boolean apply(WebDriver d) {
                return d.getPageSource().contains(pageLoadedText);
            }
        });
        return this;
    }

    /**
     * Verify that current page URL matches the expected URL.
     *
     * @return the ShopPage class instance.
     */
    public ShopPage verifyPageUrl() {
        (new WebDriverWait(driver, timeout)).until(new ExpectedCondition<Boolean>() {
            public Boolean apply(WebDriver d) {
                return d.getCurrentUrl().contains(pageUrl);
            }
        });
        return this;
    }
}

