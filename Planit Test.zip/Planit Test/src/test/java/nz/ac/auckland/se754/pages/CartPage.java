package nz.ac.auckland.se754.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.util.Map;

public class CartPage {
    private Map<String, String> data;
    private WebDriver driver;
    private int timeout = 15;

    @FindBy(css = "a[href='#/cart']")
    @CacheLookup
    private WebElement cart0;

    @FindBy(css = "a[href='#/contact']")
    @CacheLookup
    private WebElement contact;

    @FindBy(css = "a[href='#/home']")
    @CacheLookup
    private WebElement home;

    @FindBy(css = "a.brand")
    @CacheLookup
    private WebElement jupiterToys;

    @FindBy(css = "#nav-login ng-login a")
    @CacheLookup
    private WebElement login;

    @FindBy(css = "#nav-logout a")
    @CacheLookup
    private WebElement logout;

    private final String pageLoadedText = "- there's nothing to see here";

    private final String pageUrl = "/#/cart";

    @FindBy(css = "#nav-shop a")
    @CacheLookup
    private WebElement shop;

    @FindBy(css = "a.btn.btn-success")
    @CacheLookup
    private WebElement startShopping;

    @FindBy(xpath = "/html/body/div[2]/div/div/strong")
    @CacheLookup
    private WebElement cartEmptyMsg;

    @FindBy(xpath = "/html/body/div[2]/div/form/table/tfoot/tr[2]/td/ng-confirm/a")
    @CacheLookup
    private WebElement cartEmptyBtn;

    @FindBy(xpath = "/html/body/div[3]/div[3]/a[1]")
    @CacheLookup
    private WebElement confirmCartEmptyYes;

    @FindBy(xpath = "/html/body/div[2]/div/form/table/tbody/tr/td[5]/ng-confirm/a")
    @CacheLookup
    private WebElement removeItemBtn;

    @FindBy(xpath = "/html/body/div[3]/div[3]/a[1]")
    @CacheLookup
    private WebElement confirmRemoveItem;

    @FindBy(xpath = "/html/body/div[2]/div/form/table/tfoot/tr[2]/td/a")
    @CacheLookup
    private WebElement cartCheckoutBtn;

    public CartPage() {
    }

    public CartPage(WebDriver driver) {
        this();
        PageFactory.initElements(driver, this);
        this.driver = driver;
    }

    public CartPage(WebDriver driver, Map<String, String> data) {
        this(driver);
        this.data = data;
    }

    public CartPage(WebDriver driver, Map<String, String> data, int timeout) {
        this(driver, data);
        this.timeout = timeout;
    }

    public boolean cartEmptyMessageVisible(){
        return cartEmptyMsg.isDisplayed();
    }

    public void clickCheckout(){
        cartCheckoutBtn.click();
    }

    /**
     * Click on Cart 0 Link.
     *
     * @return the CartPage class instance.
     */
    public CartPage clickCart0Link() {
        cart0.click();
        return this;
    }

    /**
     * Click on Contact Link.
     *
     * @return the CartPage class instance.
     */
    public CartPage clickContactLink() {
        contact.click();
        return this;
    }

    /**
     * Click on Home Link.
     *
     * @return the CartPage class instance.
     */
    public CartPage clickHomeLink() {
        home.click();
        return this;
    }

    /**
     * Click on Jupiter Toys Link.
     *
     * @return the CartPage class instance.
     */
    public CartPage clickJupiterToysLink() {
        jupiterToys.click();
        return this;
    }

    /**
     * Click on Login Link.
     *
     * @return the CartPage class instance.
     */
    public CartPage clickLoginLink() {
        login.click();
        return this;
    }

    /**
     * Click on Logout Link.
     *
     * @return the CartPage class instance.
     */
    public CartPage clickLogoutLink() {
        logout.click();
        return this;
    }

    /**
     * Click on Shop Link.
     *
     * @return the CartPage class instance.
     */
    public CartPage clickShopLink() {
        shop.click();
        return this;
    }

    /**
     * Click on Start Shopping Link.
     *
     * @return the CartPage class instance.
     */
    public CartPage clickStartShoppingLink() {
        startShopping.click();
        return this;
    }

    /**
     * Verify that the page loaded completely.
     *
     * @return the CartPage class instance.
     */
    public CartPage verifyPageLoaded() {
        (new WebDriverWait(driver, timeout)).until(new ExpectedCondition<Boolean>() {
            public Boolean apply(WebDriver d) {
                return d.getPageSource().contains(pageLoadedText);
            }
        });
        return this;
    }

    /**
     * Verify that current page URL matches the expected URL.
     *
     * @return the CartPage class instance.
     */
    public CartPage verifyPageUrl() {
        (new WebDriverWait(driver, timeout)).until(new ExpectedCondition<Boolean>() {
            public Boolean apply(WebDriver d) {
                return d.getCurrentUrl().contains(pageUrl);
            }
        });
        return this;
    }

    public void clickCartEmpty() {
        cartEmptyBtn.click();
    }

    public void confirmEmptyCartYes(){
        confirmCartEmptyYes.click();
    }

    public void clickRemoveItem() {
        removeItemBtn.click();
    }

    public void clickConfirmRemoveItem() {
        confirmRemoveItem.click();
    }
}

