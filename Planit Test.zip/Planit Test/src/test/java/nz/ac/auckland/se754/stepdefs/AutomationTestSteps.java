package nz.ac.auckland.se754.stepdefs;

import io.cucumber.java.Before;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import nz.ac.auckland.se754.pages.*;
import org.openqa.selenium.WebDriver;
import org.springframework.beans.factory.annotation.Autowired;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.fail;

public class AutomationTestSteps {
    @Autowired
    WebDriverSetup webDriverSetup;

    private WebDriver driver;
    private Home home;
    private ShopPage shop;
    private ContactPage contact;
    private CheckoutPage checkOut;
    private CartPage cart;

    @Before
    public void setup() {
        driver = webDriverSetup.getDriver();
        home = new Home(driver);
        shop = new ShopPage(driver);
        checkOut = new CheckoutPage(driver);
        contact = new ContactPage(driver);
        cart = new CartPage(driver);
    }

    @Given("I am on the homepage")
    public void i_am_on_the_home_page() {
        driver.get("https://jupiter.cloud.planittesting.com/#/");
    }

    @And("I click on the shopping page")
    public void iClickOnTheShoppingPage() {
        home.clickStartShoppingLink();

    }

    @Then("I should go to the shopping page")
    public void iShouldGoToTheShoppingPage() {
        String currentURL = driver.getCurrentUrl();
        if(!currentURL.equals("https://jupiter.cloud.planittesting.com/#/shop")){
            fail();
        }
    }

    @Given("I am on the contact page")
    public void iAmOnTheContactPage() {
        driver.get("https://jupiter.cloud.planittesting.com/#/contact");
    }

    @And("I enter details for email")
    public void iEnterDetailsForEmail() {
        contact.setEmailEmailField();
    }

    @And("I enter details for message")
    public void iEnterDetailsForMessage() {
        contact.setMessageTextareaField();
    }

    @And("I click Submit")
    public void iClickSubmit() {
        contact.clickSubmitLink();
    }

    @Then("I should see an error message")
    public void iShouldSeeAnErrorMessage() {
        if(!contact.getErr().getText().contains("won't")){
            fail("An error should have occurred due to missing forename");
        }
    }




    @And("I enter {string} for forename")
    public void iEnterForForename(String arg0) {
        contact.setForenameTextField(arg0);
    }

    @And("I enter {string} for email")
    public void iEnterForEmail(String arg0) {
        contact.setEmailEmailField(arg0);
    }

    @And("I enter {string} for message")
    public void iEnterForMessage(String arg0) {
        contact.setMessageTextareaField(arg0);
    }

    @Then("I should see a success message")
    public void i_should_see_a_success_message() {
//        String fieldText = contact.getSuccessMsg().getText().toString();

        if(!contact.getSuccessMsg().isDisplayed()){
            fail();
        }
    }

    @And("I click Login tab")
    public void iClickLoginTab() {
        home.clickLoginLink();
    }

    @And("I enter {string} for username")
    public void iEnterForUsername(String arg0) {
        home.getLoginUsername().sendKeys(arg0);
    }

    @And("I enter {string} for password")
    public void iEnterForPassword(String arg0) {
        home.getLoginPassword().sendKeys(arg0);
    }

    @Then("I shouldn't login")
    public void iShouldnTLogin() {
        if(!home.getLoginErr().isDisplayed()){
            fail();
        }
    }

    @And("I click login")
    public void iClickLogin() {
        home.getLoginBtn().click();
    }

    @Given("I am on the shopping page")
    public void iAmOnTheShoppingPage() {
        driver.get("https://jupiter.cloud.planittesting.com/#/shop");
    }

    @And("I buy the teddy bear {string} times")
    public void iBuyTheTeddyBearTimes(String arg0) {
        int times = Integer.parseInt(arg0);

        for(int i=0; i<times; i++){
            shop.clickBuy1Link();
        }
    }

    @And("I go to cart page")
    public void iGoToCartPage() {
        shop.clickCart0Link();
    }

    @Then("I should see {string} items")
    public void iShouldSeeItems(String arg0) {
        String actualCount = shop.getItemQuantity().getText();
        System.out.println("Actual: "+actualCount);
        System.out.println(arg0);
        if(!arg0.equals(actualCount)){
            fail();
        }
    }

    @And("I click checkout")
    public void iClickCheckout() {
        cart.clickCheckout();
    }

    @And("I enter {string} for address")
    public void iEnterForAddress(String arg0) {
        checkOut.setAddressTextareaField(arg0);
    }

    @And("Select {string} for card type")
    public void selectForCardType(String arg0) {
        checkOut.setCardTypeDropDownListField(arg0);
    }

    @And("I enter {string} for card number")
    public void iEnterForCardNumber(String arg0) {
        checkOut.setCardNumberTextField(arg0);
    }

    @Given("I enter {string} for delivery forename")
    public void iEnterForDeliveryForename(String arg0) {
//        checkOut.setForenameTextField(arg0);
        checkOut.getfName().sendKeys(arg0);
    }

    @And("I enter {string} for delivery email")
    public void iEnterForDeliveryEmail(String arg0) {
        checkOut.setEmailEmailField(arg0);
    }

    @Then("My order should not process")
    public void myOrderShouldNotProcess() {
        if(checkOut.getCheckoutErr().toString().contains("hands")){
            fail();
        }
    }

    @When("I click on Empty Cart")
    public void iClickOnEmptyCart() {
        cart.clickCartEmpty();
    }

    @And("I Click on Yes")
    public void iClickOnYes() {
        cart.confirmEmptyCartYes();
    }


    @When("I remove an item")
    public void iRemoveAnItem() {
        cart.clickRemoveItem();
    }

    @And("I enter {string} as telephone number")
    public void iEnterAsTelephoneNumber(String arg0) {
        contact.setTelephoneTelField(arg0);
    }

    @Then("I should see an error message for telephone number")
    public void iShouldSeeAnErrorMessageForTelephoneNumber() {
        if(!contact.getTelephoneErrMsg().isDisplayed()){
            fail("Error message should have appeared for telephone field");
        }
    }

    @Then("My cart should be empty")
    public void myCartShouldBeEmpty() {
        if(!cart.cartEmptyMessageVisible()){
            fail("Message for an empty cart should have appeared");
        }
    }

    @And("I click on Yes to remove the item")
    public void iClickOnYesToRemoveTheItem() {
        cart.clickConfirmRemoveItem();
    }

    @And("I click submit for the delivery information")
    public void iClickSubmitForTheDeliveryInformation() {
        checkOut.clickSubmitButton();
    }

    @Then("My order should be processed")
    public void myOrderShouldBeProcessed() {
        if(!checkOut.getPurchaseSuccessMsg().contains("accepted")){
            fail();
        }
    }
}
