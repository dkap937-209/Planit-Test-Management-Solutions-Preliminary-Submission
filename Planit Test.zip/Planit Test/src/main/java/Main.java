import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import java.util.*;

public class Main {
	
    public static void main(String[] args) throws InterruptedException {

		//Challenge 1: nth Fibonacci Number
		int n = 10;
		System.out.println("The fibonacci number at "+n+" is "+findNthFibNum(n));
		
		
		//Challenge 2: Character Occurrence
		String strToCheck = "Character";
		System.out.println("The character that occurs the most in "+strToCheck+" is "+findHighOcc(strToCheck));

	}

	/**
	 * Challenge 1 Function
	 *
	 * Calculated by using the previous two values of the fibonacci sequence
	 *
	 * @param n The nth number of fibonacci number to calculate
	 * @return The nth fibonacci number
	 */
	public static int findNthFibNum(int n){
		if(n == 0){
           return 0;
		}
		else if(n == 1 || n==2){
			return 1;
		}else{
			ArrayList<Integer> list = new ArrayList<>();
			list.add(1);
			list.add(1);
			  
			for(int i=2; i<n; i++){
				list.add(list.get(i-1)+list.get(i-2));
			}
			return list.get(n-1);
      }
	}
	

	/**
	 * Challenge 2 Function
	 *
	 * Works by first calculating the number of occurrences of each character.
	 * Then finding the character with the highest occurrence and looping through
	 * the string to find the first character that matches that number of occurrences.
	 *
	 * @param strToCheck String to find character with most occurrences
	 * @return Character with most occurrences
	 */
	public static Character findHighOcc(String strToCheck){
		strToCheck = strToCheck.toLowerCase();

		Map<Character, Integer> map = new TreeMap<>();
		char[] chars = strToCheck.toCharArray();

		//Calculating occurrences of each character
		for(Character c: chars){
			  if(!map.containsKey(c)){
				  map.put(c, 1);
			  }
			  else{
				  int count = map.get(c)+1;
				  map.replace(c, count);
			  }
		}

		Collection<Integer> counts = map.values();

		int maxCount = Collections.max(counts);

		for(Character c: chars){
			if(map.get(c) == maxCount){
				return c;
			}
		}

		return null;
	}
}