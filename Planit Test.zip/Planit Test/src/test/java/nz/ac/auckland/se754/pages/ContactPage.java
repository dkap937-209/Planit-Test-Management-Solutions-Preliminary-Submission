package nz.ac.auckland.se754.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.util.Map;

public class ContactPage {
    private Map<String, String> data;
    private WebDriver driver;
    private int timeout = 15;

    @FindBy(css = "a[href='#/cart']")
    @CacheLookup
    private WebElement cart0;

    @FindBy(css = "a[href='#/contact']")
    @CacheLookup
    private WebElement contact;

    @FindBy(id = "email")
    @CacheLookup
    private WebElement email;

    @FindBy(id = "forename")
    @CacheLookup
    private WebElement forename;

    @FindBy(css = "a[href='#/home']")
    @CacheLookup
    private WebElement home;

    @FindBy(css = "a.brand")
    @CacheLookup
    private WebElement jupiterToys;

    @FindBy(css = "#nav-login ng-login a")
    @CacheLookup
    private WebElement login;

    @FindBy(css = "#nav-logout a")
    @CacheLookup
    private WebElement logout;

    @FindBy(id = "message")
    @CacheLookup
    private WebElement message;

    private final String pageLoadedText = "Your email address will only be used in reply to this message";

    private final String pageUrl = "/#/contact";

    @FindBy(css = "a[href='#/shop']")
    @CacheLookup
    private WebElement shop;

    @FindBy(css = "a.btn-contact.btn.btn-primary")
    @CacheLookup
    private WebElement submit;

    @FindBy(id = "surname")
    @CacheLookup
    private WebElement surname;

    @FindBy(id = "telephone")
    @CacheLookup
    private WebElement telephone;

    @FindBy(xpath = "/html/body/div[2]/div/div/div")
    private WebElement err;

    @FindBy(xpath = "/html/body/div[2]/div/div")
    private WebElement successMsg;

    @FindBy(xpath = "/html/body/div[2]/div/form/fieldset/div[4]/div/span[1]")
    private WebElement telephoneErrMsg;

    public ContactPage() {
    }

    public ContactPage(WebDriver driver) {
        this();
        PageFactory.initElements(driver, this);
        this.driver = driver;
    }

    public ContactPage(WebDriver driver, Map<String, String> data) {
        this(driver);
        this.data = data;
    }

    public ContactPage(WebDriver driver, Map<String, String> data, int timeout) {
        this(driver, data);
        this.timeout = timeout;
    }

    public WebElement getTelephoneErrMsg() {
        return telephoneErrMsg;
    }

    public WebElement getErr() {
        return err;
    }

    public WebElement getSuccessMsg() {
        return successMsg;
    }

    /**
     * Click on Cart 0 Link.
     *
     * @return the Contact class instance.
     */
    public ContactPage clickCart0Link() {
        cart0.click();
        return this;
    }

    /**
     * Click on Contact Link.
     *
     * @return the Contact class instance.
     */
    public ContactPage clickContactLink() {
        contact.click();
        return this;
    }

    /**
     * Click on Home Link.
     *
     * @return the Contact class instance.
     */
    public ContactPage clickHomeLink() {
        home.click();
        return this;
    }

    /**
     * Click on Jupiter Toys Link.
     *
     * @return the Contact class instance.
     */
    public ContactPage clickJupiterToysLink() {
        jupiterToys.click();
        return this;
    }

    /**
     * Click on Login Link.
     *
     * @return the Contact class instance.
     */
    public ContactPage clickLoginLink() {
        login.click();
        return this;
    }

    /**
     * Click on Logout Link.
     *
     * @return the Contact class instance.
     */
    public ContactPage clickLogoutLink() {
        logout.click();
        return this;
    }

    /**
     * Click on Shop Link.
     *
     * @return the Contact class instance.
     */
    public ContactPage clickShopLink() {
        shop.click();
        return this;
    }

    /**
     * Click on Submit Link.
     *
     * @return the Contact class instance.
     */
    public ContactPage clickSubmitLink() {
        submit.click();
        return this;
    }

    /**
     * Fill every fields in the page.
     *
     * @return the Contact class instance.
     */
    public ContactPage fill() {
        setForenameTextField();
        setSurnameTextField();
        setEmailEmailField();
        setTelephoneTelField();
        setMessageTextareaField();
        return this;
    }

    /**
     * Fill every fields in the page and submit it to target page.
     *
     * @return the Contact class instance.
     */
    public ContactPage fillAndSubmit() {
        fill();
        return submit();
    }

    /**
     * Set default value to Email Email field.
     *
     * @return the Contact class instance.
     */
    public ContactPage setEmailEmailField() {
        return setEmailEmailField("email@gmail.com");
    }

    /**
     * Set value to Email Email field.
     *
     * @return the Contact class instance.
     */
    public ContactPage setEmailEmailField(String emailValue) {
        email.sendKeys(emailValue);
        return this;
    }

    /**
     * Set default value to Forename Text field.
     *
     * @return the Contact class instance.
     */
    public ContactPage setForenameTextField() {
        return setForenameTextField("FORENAME");
    }

    /**
     * Set value to Forename Text field.
     *
     * @return the Contact class instance.
     */
    public ContactPage setForenameTextField(String forenameValue) {
        forename.sendKeys(forenameValue);
        return this;
    }

    /**
     * Set default value to Message Textarea field.
     *
     * @return the Contact class instance.
     */
    public ContactPage setMessageTextareaField() {
        return setMessageTextareaField("MESSAGE");
    }

    /**
     * Set value to Message Textarea field.
     *
     * @return the Contact class instance.
     */
    public ContactPage setMessageTextareaField(String messageValue) {
        message.sendKeys(messageValue);
        return this;
    }

    /**
     * Set default value to Surname Text field.
     *
     * @return the Contact class instance.
     */
    public ContactPage setSurnameTextField() {
        return setSurnameTextField("SURNAME");
    }

    /**
     * Set value to Surname Text field.
     *
     * @return the Contact class instance.
     */
    public ContactPage setSurnameTextField(String surnameValue) {
        surname.sendKeys(surnameValue);
        return this;
    }

    /**
     * Set default value to Telephone Tel field.
     *
     * @return the Contact class instance.
     */
    public ContactPage setTelephoneTelField() {
        return setTelephoneTelField(data.get("TELEPHONE"));
    }

    /**
     * Set value to Telephone Tel field.
     *
     * @return the Contact class instance.
     */
    public ContactPage setTelephoneTelField(String telephoneValue) {
        telephone.sendKeys(telephoneValue);
        return this;
    }

    /**
     * Submit the form to target page.
     *
     * @return the Contact class instance.
     */
    public ContactPage submit() {
        clickSubmitLink();
        return this;
    }

    /**
     * Verify that the page loaded completely.
     *
     * @return the Contact class instance.
     */
    public ContactPage verifyPageLoaded() {
        (new WebDriverWait(driver, timeout)).until(new ExpectedCondition<Boolean>() {
            public Boolean apply(WebDriver d) {
                return d.getPageSource().contains(pageLoadedText);
            }
        });
        return this;
    }

    /**
     * Verify that current page URL matches the expected URL.
     *
     * @return the Contact class instance.
     */
    public ContactPage verifyPageUrl() {
        (new WebDriverWait(driver, timeout)).until(new ExpectedCondition<Boolean>() {
            public Boolean apply(WebDriver d) {
                return d.getCurrentUrl().contains(pageUrl);
            }
        });
        return this;
    }
}

